from urllib2 import Request, urlopen

values = """
  {
    "sendSmsRequest": {
      "from": "Remetente",
      "to": "555199999999",
      "schedule": "2014-08-22T14:55:00",
      "msg": "Mensagem de teste",
      "callbackOption": "NONE",
      "id": "002",
      "aggregateId": "1111",
      "flashSms": false
    }
  }
"""

headers = {
  'Content-Type': 'application/json',
  'Authorization': 'Basic YWRtaW46YWRtaW4=',
  'Accept': 'application/json'
}
request = Request('https://api-rest.zenvia.com/services/send-sms', data=values, headers=headers)

response_body = urlopen(request).read()
print(response_body)