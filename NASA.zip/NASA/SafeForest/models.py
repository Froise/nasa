from django.db import models
import uuid

class Usuario(models.Model):
    usuario_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, primary_key=True)
    nome_usuario = models.CharField(max_length=150)
    email = models.EmailField()
    telefone_DDI = models.CharField(max_length=3)
    telefone_DDD = models.CharField(max_length=2)
    telefone_num = models.CharField(max_length=13)

