from django.shortcuts import render
import requests

def enviarsms(requests):
    values = f"""
      {
        "sendSmsRequest": {
          "from": "Remetente",
          "to": "555199999999",
          "schedule": "2014-08-22T14:55:00",
          "msg": "Mensagem de teste",
          "callbackOption": "NONE",
          "id": "002",
          "aggregateId": "1111",
          "flashSms": false
        }
      }
    """

    headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Basic YWRtaW46YWRtaW4=',
      'Accept': 'application/json'
    }
    request = requests.post('https://api-rest.zenvia.com/services/send-sms', data=values, headers=headers)

    response_body = request.json()
    #print(response_body)
    return render(request, 'teste.html', {'sms': response_body,})

def verificarFocoPais(requests,pais):
    texto = requests.POST.get(f'http://queimadas.dgi.inpe.br/queimadas/dados-abertos/api/focos/?pais_id={pais}')
    return render(requests, 'teste.html', { 'teste': texto,})

def verificarFocoEstado(requests,pais,estado):
    texto = requests.POST.get(f'http://queimadas.dgi.inpe.br/queimadas/dados-abertos/api/focos/?pais_id={pais}&estado_id={estado}')
    return render(requests, 'teste.html', { 'teste': texto,})

def verificarFocoMunicipio(requests,pais,estado,municipio):
    texto = requests.POST.get(f'http://queimadas.dgi.inpe.br/queimadas/dados-abertos/api/focos/?pais_id={pais}&estado_id={estado}&municipio_id={municipio}')
    return render(requests, 'teste.html', { 'teste': texto,})