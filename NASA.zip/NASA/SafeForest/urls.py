from django.urls import path
from django.contrib import admin
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns



urlpatterns = [
    #path('', views.verificarFocoTudo),
    #path('api/focos/', admin.site.urls),
    path('api/focos/pais_id=<int:pais>', views.verificarFocoPais),
    path('api/focos/pais_id=<int:pais>&estado_id=<int:estado>', views.verificarFocoEstado),
    path('api/focos/pais_id=<int:pais>&estado_id=<int:estado>&municipio_id=<int:municipio>', views.verificarFocoMunicipio),

]
urlpatterns += staticfiles_urlpatterns()

