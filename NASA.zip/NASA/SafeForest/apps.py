from django.apps import AppConfig


class SafeforestConfig(AppConfig):
    name = 'SafeForest'
