import json
import requests


texto = requests.get('http://queimadas.dgi.inpe.br/queimadas/dados-abertos/api/focos/')
print(texto.json())
#js = json.load('https://api-rest.zenvia.com/services/send-sms', data=values, headers=headers)
#response_body = requests.get(texto).read()

#print(response_body)
#print(js)
